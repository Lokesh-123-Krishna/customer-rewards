import { useMemo, useState } from "react";

import PropTypes from "prop-types";

import { Box, Tab, Tabs } from "@mui/material";

import { getCustomerMonthlyRewards } from "../services/rewardCalculatorService";

import MonthlyRewardsCard from "../../components/customer/MonthlyRewardsCard";

const MonthlyRewardTabs = ({ transactions }) => {
  const monthlyRewards = useMemo(
    () => getCustomerMonthlyRewards(transactions),
    [transactions],
  );

  const [selectedTab, setSelectedTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  return (
    <>
      <Tabs value={selectedTab} onChange={handleTabChange} sx={{ mb: 3 }}>
        {monthlyRewards.map((reward) => (
          <Tab key={reward.month} label={reward.month} />
        ))}
      </Tabs>

      {monthlyRewards[selectedTab] && (
        <Box mb={4}>
          <MonthlyRewardsCard
            month={monthlyRewards[selectedTab].month}
            rewardPoints={monthlyRewards[selectedTab].rewardPoints}
            transactionCount={monthlyRewards[selectedTab].transactionCount}
          />
        </Box>
      )}
    </>
  );
};

MonthlyRewardTabs.propTypes = {
  transactions: PropTypes.array.isRequired,
};

export default MonthlyRewardTabs;
