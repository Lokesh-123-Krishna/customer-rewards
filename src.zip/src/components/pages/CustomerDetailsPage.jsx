import { useMemo } from "react";

import { useParams } from "react-router-dom";

import MainLayout from "../layouts/MainLayout";
import AppLoader from "../../components/common/AppLoader";
import ErrorState from "../../components/common/ErrorState";
import EmptyState from "../../components/common/EmptyState";
import CustomerSummary from "../../components/customer/CustomerSummary";
import MonthlyRewardTabs from "../../components/customer/MonthlyRewardTabs";
import TransactionTable from "../../components/customer/TransactionTable";

import { useCustomers } from "../hooks/useCustomers";

import { getCustomerById } from "../services/customerService";

const CustomerDetailsPage = () => {
  const { customerId } = useParams();

  const { transactions, loading, error, refetch } = useCustomers();

  const customer = useMemo(
    () => getCustomerById(transactions, customerId),
    [transactions, customerId],
  );

  if (loading) {
    return (
      <MainLayout>
        <AppLoader />
      </MainLayout>
    );
  }

  if (error) {
    return (
      <MainLayout>
        <ErrorState message={error} onRetry={refetch} />
      </MainLayout>
    );
  }

  if (!customer) {
    return (
      <MainLayout>
        <EmptyState title="Customer Not Found" />
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <CustomerSummary customer={customer} />

      <MonthlyRewardTabs transactions={customer.transactions} />

      <TransactionTable transactions={customer.transactions} />

    </MainLayout>
  );
};

export default CustomerDetailsPage;
